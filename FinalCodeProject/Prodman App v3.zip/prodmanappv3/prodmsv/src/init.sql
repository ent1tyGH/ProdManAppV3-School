USE prodmsdb;
INSERT INTO uom_data(id,name)VALUES(1, 'kg');
INSERT INTO uom_data(id,name)VALUES(2,'oz');
INSERT INTO uom_data(id,name)VALUES(3,'gram');
INSERT INTO uom_data(id,name)VALUES(4,'pc');