package com.gabriel.prodmsv;

import javafx.application.Application;

public class ProdManApplication  {
    public static void main(String[] args) {

        Application.launch(SplashApp.class, args);
    }
}