package com.gabriel.prodmsapp.repository;

import com.gabriel.prodmsapp.entity.ProductData;
import org.springframework.data.repository.CrudRepository;

public interface ProductDataRepository extends CrudRepository<ProductData,Integer> {}
