package com.gabriel.prodmsapp.repository;

import com.gabriel.prodmsapp.entity.ProductData;
import com.gabriel.prodmsapp.entity.UomData;
import org.springframework.data.repository.CrudRepository;

public interface UomDataRepository extends CrudRepository<UomData,Integer> {}
